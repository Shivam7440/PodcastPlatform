<?php
// PHPMailer configuration
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USERNAME', 'kamakshiagg2005@gmail.com'); // Gmail address
define('SMTP_PASSWORD', 'lfwo zzri pfzx cwde'); // Gmail app password
define('SMTP_FROM_EMAIL', 'kamakshiagg2005@gmail.com'); // Sender email
define('SMTP_FROM_NAME', 'PodcastPro');
?>